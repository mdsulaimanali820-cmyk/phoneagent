package com.example.phoneagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    /** Sends one request to Gemini (Google AI Studio key) and returns the text reply. */
    fun call(apiKey: String, model: String, system: String, userText: String): String {
        val m = model.trim().removePrefix("models/")
        val url = URL("$BASE/models/$m:generateContent")
        val body = JSONObject()
        body.put("systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        body.put("contents", JSONArray().put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))))
        body.put("generationConfig",
            JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2))

        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", apiKey.trim())
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${txt.take(500)}")

        val j = JSONObject(txt)
        val cand = j.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw RuntimeException("কোনো উত্তর নেই (blocked?): ${txt.take(400)}")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
            ?: throw RuntimeException("খালি উত্তর: ${txt.take(400)}")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    /** Lists models available for this key that support generateContent. */
    fun listModels(apiKey: String): String {
        val c = URL("$BASE/models?pageSize=100").openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("x-goog-api-key", apiKey.trim())
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${txt.take(500)}")
        val arr = JSONObject(txt).optJSONArray("models") ?: return "(কোনো মডেল নেই)"
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val methods = o.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (methods.contains("generateContent")) out.add(o.optString("name").removePrefix("models/"))
        }
        return out.filter { it.startsWith("gemini") }.joinToString("\n")
    }
}
