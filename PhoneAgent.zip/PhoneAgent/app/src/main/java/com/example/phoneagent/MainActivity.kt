package com.example.phoneagent

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.*
import java.util.Locale

object Logger {
    val sb = StringBuilder()
    @Volatile var onChange: (() -> Unit)? = null
    fun add(s: String) {
        synchronized(sb) { sb.append(s).append("\n") }
        onChange?.invoke()
    }
}

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var status: TextView
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var goalEt: EditText
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private val REQ_VOICE = 11

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(16))

        val title = TextView(this)
        title.text = "📱 Phone Agent"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        status = TextView(this)
        root.addView(status)

        keyEt = EditText(this)
        keyEt.hint = "Google AI Studio API Key"
        keyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyEt.setText(prefs.getString("key", ""))
        root.addView(keyEt)

        modelEt = EditText(this)
        modelEt.hint = "Model (যেমন gemini-flash-latest)"
        modelEt.setText(prefs.getString("model", "gemini-flash-latest"))
        root.addView(modelEt)

        val row1 = LinearLayout(this)
        row1.addView(btn("💾 Save") { save(); toast("Saved") })
        row1.addView(btn("🔌 API Test") { testApi() })
        row1.addView(btn("📋 Models") { listModels() })
        root.addView(row1)

        root.addView(btn("♿ Accessibility চালু করুন") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        goalEt = EditText(this)
        goalEt.hint = "কী করতে হবে? (যেমন: হোয়াটসঅ্যাপ খুলে ...)"
        goalEt.minLines = 2
        root.addView(goalEt)

        val row2 = LinearLayout(this)
        row2.addView(btn("▶️ Run") { runGoal() })
        row2.addView(btn("🎤 Voice") { startVoice() })
        row2.addView(btn("⏹ Stop") { AgentService.instance?.stop() })
        root.addView(row2)

        logView = TextView(this)
        logView.setTextColor(Color.DKGRAY)
        logView.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(logView)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("bn", "BD"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
                    tts?.setLanguage(Locale.US)
            }
        }

        Logger.onChange = { runOnUiThread { refreshLog(sv) } }
        refreshLog(sv)
    }

    private fun refreshLog(sv: ScrollView? = null) {
        synchronized(Logger.sb) { logView.text = Logger.sb.toString() }
        sv?.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AgentService.instance != null) "Accessibility: ✅ চালু" else "Accessibility: ❌ বন্ধ (নিচের বাটন চাপুন)"
    }

    private fun save() {
        prefs.edit().putString("key", keyEt.text.toString().trim())
            .putString("model", modelEt.text.toString().trim()).apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun testApi() {
        save()
        val key = keyEt.text.toString(); val model = modelEt.text.toString()
        if (key.isBlank()) { toast("আগে API key দিন"); return }
        Logger.add("🔌 টেস্ট হচ্ছে: $model ...")
        Thread {
            try {
                val r = Gemini.call(key, model, "Reply with JSON only.", "Return {\"ok\":true}")
                Logger.add("✅ API ঠিক আছে: ${r.take(80)}")
            } catch (e: Exception) {
                Logger.add("❌ API ব্যর্থ: ${e.message}")
            }
        }.start()
    }

    private fun listModels() {
        save()
        val key = keyEt.text.toString()
        if (key.isBlank()) { toast("আগে API key দিন"); return }
        Thread {
            try { Logger.add("📋 আপনার key-এর মডেল:\n" + Gemini.listModels(key)) }
            catch (e: Exception) { Logger.add("❌ ${e.message}") }
        }.start()
    }

    private fun runGoal() {
        save()
        val goal = goalEt.text.toString().trim()
        val key = keyEt.text.toString(); val model = modelEt.text.toString()
        if (goal.isBlank()) { toast("কাজ লিখুন"); return }
        if (key.isBlank()) { toast("API key দিন"); return }
        val svc = AgentService.instance
        if (svc == null) {
            toast("আগে Accessibility চালু করুন")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        svc.runGoal(goal, key, model) { msg -> tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "m") }
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন...")
        try { startActivityForResult(i, REQ_VOICE) }
        catch (e: ActivityNotFoundException) { toast("ভয়েস ইনপুট সাপোর্ট নেই, টাইপ করুন") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) { goalEt.setText(t); runGoal() }
        }
    }

    override fun onDestroy() {
        Logger.onChange = null
        tts?.shutdown()
        super.onDestroy()
    }
}
