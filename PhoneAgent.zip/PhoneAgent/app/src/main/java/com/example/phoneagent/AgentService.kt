package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        private const val MAX_STEPS = 30

        private const val SYSTEM = """You control an Android phone by outputting exactly ONE JSON action per turn.
The user's goal may be in Bengali or English. Write "message" in the user's language.
You receive the screen as numbered elements: [index] class "text" flags (centerX,centerY).

Actions (output JSON only, no extra text):
{"action":"open_app","app":"WhatsApp"}
{"action":"open_uri","uri":"https://... or tel:017... or sms:017..."}
{"action":"tap","index":N}
{"action":"type","index":N,"text":"..."}
{"action":"enter"}
{"action":"scroll","direction":"up|down|left|right"}   (direction = finger swipe direction; to see lower content use "up")
{"action":"back"}
{"action":"home"}
{"action":"wait"}
{"action":"done","message":"short result for the user"}
{"action":"ask","message":"question, or request for confirmation"}

Rules:
- One action per turn. Add a short "reason" field.
- If the screen did not change after your last action, try a different approach.
- Never pay, transfer money, delete data, or send a message/post unless the goal clearly asks for it; if unsure use "ask".
- When the goal is achieved, use "done"."""
    }

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    override fun onServiceConnected() {
        instance = this
        Logger.add("✅ Accessibility সার্ভিস চালু")
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun stop() { running = false }
    fun isRunning() = running

    fun runGoal(goal: String, key: String, model: String, speak: (String) -> Unit) {
        if (running) { Logger.add("⚠️ আগের কাজ এখনো চলছে"); return }
        running = true
        Logger.add("▶️ কাজ শুরু: $goal")
        Thread {
            val history = ArrayList<String>()
            try {
                val dm = resources.displayMetrics
                for (step in 1..MAX_STEPS) {
                    if (!running) { Logger.add("⏹ থামানো হয়েছে"); break }
                    val root = rootInActiveWindow
                    val nodes = ArrayList<AccessibilityNodeInfo>()
                    val desc = StringBuilder()
                    if (root != null) collect(root, nodes, desc, 0)
                    val pkg = root?.packageName?.toString() ?: "unknown"
                    val prompt = "GOAL: $goal\nCURRENT APP: $pkg\nSCREEN: ${dm.widthPixels}x${dm.heightPixels}\n" +
                        "HISTORY:\n${history.takeLast(8).joinToString("\n")}\nELEMENTS:\n$desc"

                    val reply = Gemini.call(key, model, SYSTEM, prompt)
                    val a = parse(reply)
                    val act = a.optString("action")
                    Logger.add("[$step] $act ${a.optString("reason")}")
                    history.add("step $step: ${a.toString().take(200)}")

                    var finished = false
                    when (act) {
                        "open_app" -> if (!openApp(a.optString("app"))) Logger.add("❌ অ্যাপ পাওয়া যায়নি: ${a.optString("app")}")
                        "open_uri" -> openUri(a.optString("uri"))
                        "tap" -> {
                            val i = a.optInt("index", -1)
                            if (i in nodes.indices) {
                                val r = Rect(); nodes[i].getBoundsInScreen(r)
                                tap(r.exactCenterX(), r.exactCenterY())
                            } else if (a.has("x") && a.has("y")) tap(a.getDouble("x").toFloat(), a.getDouble("y").toFloat())
                            else Logger.add("❌ ভুল index")
                        }
                        "type" -> {
                            val i = a.optInt("index", -1)
                            val node = if (i in nodes.indices) nodes[i] else root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                            if (node == null) Logger.add("❌ টাইপ করার জায়গা নেই") else {
                                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                                val b = Bundle()
                                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                                node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                            }
                        }
                        "enter" -> {
                            val node = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                            if (node != null && Build.VERSION.SDK_INT >= 30)
                                node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                            else Logger.add("❌ Enter দেওয়া গেল না, কীবোর্ডের বাটন ট্যাপ করুন")
                        }
                        "scroll" -> swipe(a.optString("direction"), dm.widthPixels, dm.heightPixels)
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "wait" -> {}
                        "done" -> { val m = a.optString("message", "শেষ"); Logger.add("✅ $m"); speak(m); finished = true }
                        "ask" -> { val m = a.optString("message"); Logger.add("❓ $m"); speak(m); finished = true }
                        else -> Logger.add("❌ অজানা অ্যাকশন: $act")
                    }
                    if (finished) break
                    if (step == MAX_STEPS) Logger.add("⚠️ $MAX_STEPS ধাপে শেষ হয়নি")
                    Thread.sleep(1500)
                }
            } catch (e: Exception) {
                Logger.add("❌ ${e.javaClass.simpleName}: ${e.message}")
            }
            running = false
        }.start()
    }

    private fun parse(reply: String): JSONObject {
        var t = reply.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (t.startsWith("[")) t = JSONArray(t).getJSONObject(0).toString()
        return JSONObject(t)
    }

    private fun collect(n: AccessibilityNodeInfo, out: ArrayList<AccessibilityNodeInfo>, sb: StringBuilder, depth: Int) {
        if (out.size >= 90 || depth > 40) return
        val text = (n.text ?: n.contentDescription ?: n.hintText ?: "").toString().replace("\n", " ").take(60)
        val useful = n.isClickable || n.isEditable || n.isScrollable || text.isNotBlank()
        if (n.isVisibleToUser && useful) {
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) {
                val flags = buildString {
                    if (n.isClickable) append("click ")
                    if (n.isEditable) append("input ")
                    if (n.isScrollable) append("scroll ")
                }.trim()
                sb.append("[${out.size}] ${n.className?.toString()?.substringAfterLast('.')} \"$text\" $flags (${r.centerX()},${r.centerY()})\n")
                out.add(n)
            }
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out, sb, depth + 1) }
    }

    private fun gesture(path: Path, dur: Long): Boolean {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val latch = CountDownLatch(1)
        var ok = false
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, ui)
        latch.await(5, TimeUnit.SECONDS)
        return ok
    }

    private fun tap(x: Float, y: Float) {
        val p = Path(); p.moveTo(x, y)
        if (!gesture(p, 60)) Logger.add("⚠️ ট্যাপ হয়নি")
    }

    private fun swipe(dir: String, w: Int, h: Int) {
        val p = Path()
        val cx = w / 2f; val cy = h / 2f
        when (dir) {
            "up" -> { p.moveTo(cx, h * 0.75f); p.lineTo(cx, h * 0.25f) }
            "down" -> { p.moveTo(cx, h * 0.25f); p.lineTo(cx, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, cy); p.lineTo(w * 0.2f, cy) }
            else -> { p.moveTo(w * 0.2f, cy); p.lineTo(w * 0.8f, cy) }
        }
        gesture(p, 350)
    }

    private fun openApp(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        val q = name.trim().lowercase()
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: list.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
            ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun openUri(uri: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) { Logger.add("❌ লিংক খোলা যায়নি: ${e.message}") }
    }
}
