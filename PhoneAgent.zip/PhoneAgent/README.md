# Phone Agent (Gemini / Google AI Studio)

## বিল্ড
1. Android Studio (Koala+) তে এই ফোল্ডার Open করুন, Gradle Sync শেষ হতে দিন।
2. ফোনে USB debugging চালু করে Run চাপুন (অথবা Build > Build APK).

## প্রথমবার সেটআপ (এখানেই বেশিরভাগ সময় আটকে যায়)
1. https://aistudio.google.com/apikey থেকে API key নিন, অ্যাপে বসিয়ে Save করুন।
2. **🔌 API Test** চাপুন। সবুজ ✅ না এলে লগের এরর দেখুন (নিচে টেবিল)।
3. **♿ Accessibility** বাটন চেপে "Phone Agent" সার্ভিস চালু করুন।
   - Android 13+ এ APK সাইডলোড করলে সুইচটা ধূসর থাকে। তখন: Settings > Apps > Phone Agent > ⋮ (উপরে ডানে) > **Allow restricted settings**, তারপর আবার চালু করুন।
4. কাজ লিখুন বা 🎤 চাপুন, তারপর ▶️ Run।

## এরর বুঝবেন কীভাবে
| লগে যা দেখছেন | মানে |
|---|---|
| HTTP 400 API key not valid | key ভুল/কপিতে স্পেস |
| HTTP 404 model not found | মডেলের নাম ভুল/পুরনো → 📋 Models চাপুন, লিস্ট থেকে একটা বসান |
| HTTP 429 | ফ্রি লিমিট শেষ, কিছুক্ষণ পর বা অন্য মডেল |
| UnknownHostException | ইন্টারনেট নেই |
| "Accessibility বন্ধ" | ধাপ ৩ বাকি |
